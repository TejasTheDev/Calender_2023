import './App.css';
// import Horoscopee from './components/Horoscopee';
import TodayHoroscope from './components/Calander'

function App() {
  return (
    <div className="container">
      {/* <Horoscopee /> */}
      <TodayHoroscope />
    </div>
  );
}

export default App;
